"""Public, read-only liquidity snapshot. No credentials or trades."""
import ast
import concurrent.futures
import datetime as dt
import json
import pathlib
import re
import time
import urllib.error
import urllib.parse
import urllib.request

ROOT = pathlib.Path(__file__).resolve().parent
RAW = ROOT / 'raw'

def get(key, url):
    start = dt.datetime.now(dt.timezone.utc).isoformat()
    record = {'url': url, 'requested_at': start}
    try:
        req = urllib.request.Request(url, headers={'User-Agent': 'PragmaLiquidityReview/1.0', 'Accept': 'application/json'})
        with urllib.request.urlopen(req, timeout=25) as response:
            record.update(status=response.status, data=json.load(response))
    except urllib.error.HTTPError as e:
        record.update(status=e.code, error=e.read().decode(errors='replace')[:600])
    except Exception as e:
        record['error'] = str(e)
    record['received_at'] = dt.datetime.now(dt.timezone.utc).isoformat()
    (RAW / (key + '.json')).write_text(json.dumps(record))
    return record

def inventory():
    rows = {}
    for publisher in ['PRAGMA','ARGENT','STARKWARE','STARKNET_FOUNDATION','AVNU']:
        for c in json.loads((RAW/(publisher+'.json')).read_text())['components']:
            key = (c['pair_id'],c['source'])
            rows.setdefault(key, []).append({'publisher':publisher,**c})
    return rows

VENUES = {'BINANCE','BITGET','BITSTAMP','BYBIT','GATEIO','HUOBI','KUCOIN','LBANK','OKX'}

def book_url(source, base, quote):
    if source == 'BINANCE': return f'https://api.binance.com/api/v3/depth?symbol={base}{quote}&limit=5000'
    if source == 'BITGET': return f'https://api.bitget.com/api/v2/spot/market/orderbook?symbol={base}{quote}&type=step0&limit=200'
    if source == 'BITSTAMP': return f'https://www.bitstamp.net/api/v2/order_book/{base.lower()}{quote.lower()}/'
    if source == 'BYBIT': return f'https://api.bybit.com/v5/market/orderbook?category=spot&symbol={base}{quote}&limit=200'
    if source == 'GATEIO': return f'https://api.gateio.ws/api/v4/spot/order_book?currency_pair={base}_{quote}&limit=1000'
    if source == 'HUOBI': return f'https://api.huobi.pro/market/depth?symbol={base.lower()}{quote.lower()}&type=step0&depth=150'
    if source == 'KUCOIN': return f'https://api.kucoin.com/api/v1/market/orderbook/level2_100?symbol={base}-{quote}'
    if source == 'LBANK': return f'https://api.lbkex.com/v2/depth.do?symbol={base.lower()}_{quote.lower()}&size=200'
    if source == 'OKX': return f'https://www.okx.com/api/v5/market/books?instId={base}-{quote}-SWAP&sz=400'
    if source == 'KRAKEN': return f'https://api.kraken.com/0/public/Depth?pair={"XBT" if base == "BTC" else base}{quote}&count=500'
    if source == 'COINBASE': return f'https://api.exchange.coinbase.com/products/{base}-{quote}/book?level=2'

def run_books():
    tasks = {}
    for (pair, source) in inventory():
        if source not in VENUES: continue
        base,quote = pair.split('/')
        quote = 'USD' if source=='BITSTAMP' or base=='USDT' else 'USDT'
        tasks[f'book-{source}-{base}-{quote}'] = book_url(source,base,quote)
    # Independently inspect USD reference legs and Miden asset markets.
    # These do not establish which markets Miden publishers use.
    for base in ['BTC','ETH','USDT','USDC','DAI','ZEC','XMR','DASH','XAUT','PAXG','LINK','UNI','AAVE','MORPHO']:
        for source in ['KRAKEN','COINBASE']:
            tasks[f'book-{source}-{base}-USD'] = book_url(source,base,'USD')
    for base in ['ZEC','XMR','DASH','XAUT','PAXG','LINK','UNI','AAVE','MORPHO','WBTC']:
        for source in ['BINANCE','BYBIT']:
            tasks[f'book-{source}-{base}-USDT'] = book_url(source,base,'USDT')
    tasks['okx-instruments'] = 'https://www.okx.com/api/v5/public/instruments?instType=SWAP'
    with concurrent.futures.ThreadPoolExecutor(6) as pool:
        for key, rec in pool.map(lambda kv:(kv[0],get(*kv)),tasks.items()):
            print(key,rec.get('status',rec.get('error')),flush=True)

def asset_config():
    # Read the simple public SDK YAML without introducing a dependency.
    data={}
    for block in (ROOT/'sdk/assets.yaml').read_text().split('- name:')[1:]:
        row=dict(re.findall(r'^\s+(\w+):\s*[\'\"]?([^\n\'\"#]+)',block,re.M))
        if 'ticker' in row: data[row['ticker'].strip()]={k:v.strip() for k,v in row.items()}
    return data

def run_dex():
    config=asset_config()
    bases=sorted({p.split('/')[0] for p,s in inventory()})
    for base in bases:
        c=config.get(base,{})
        for network,field in [('starknet-alpha','starknet_address'),('eth','ethereum_address')]:
            if field not in c:continue
            addr=c[field]
            rec=get(f'pools-{base}-{network}',f'https://api.geckoterminal.com/api/v2/networks/{network}/tokens/{addr}/pools?page=1')
            print('pools',base,network,rec.get('status'),flush=True)
            time.sleep(2.1)
    ids=','.join('coingecko:'+config[b]['coingecko_id'] for b in bases if config.get(b,{}).get('coingecko_id'))
    get('defillama','https://coins.llama.fi/prices/current/'+ids)

def quote(base, direction, notional, token, usdc, amount):
    sell,buy=(usdc,token) if direction=='buy' else (token,usdc)
    url='https://starknet.api.avnu.fi/swap/v3/quotes?'+urllib.parse.urlencode({
        'sellTokenAddress':sell,'buyTokenAddress':buy,'sellAmount':hex(amount),'size':1})
    return get(f'quote-{base}-{direction}-{notional}',url)

def run_quotes():
    config=asset_config();usdc=config['USDC']['starknet_address']
    bases=sorted({p.split('/')[0] for p,s in inventory()}-{'BTC','USDC'})
    def work(base):
        if (RAW/f'quote-{base}-sell-100000.json').exists():return
        query=config.get(base,{}).get('starknet_address',base.lower())
        rec=get('token-'+base,'https://starknet.api.avnu.fi/v1/starknet/tokens/'+query)
        token=rec.get('data',{})
        if not token.get('address') or (not query.startswith('0x') and token.get('symbol','').upper()!=base):
            print(base,'token unavailable',flush=True);return
        # Prefer the explicit token identity in the public SDK where supplied.
        address=config.get(base,{}).get('starknet_address',token['address'])
        d=int(token['decimals'])
        if int(address,16)!=int(token['address'],16):
            print(base,'address mismatch',flush=True);return
        small=quote(base,'buy',10,address,usdc,10*10**6)
        if not isinstance(small.get('data'),list) or not small['data']:
            print(base,'baseline unavailable',flush=True);return
        # Use the 10 USDC quote to size token sales; keep integer arithmetic.
        quantity=int(small['data'][0]['buyAmount'],16)
        for n in [10,100,1000,10000,100000]:
            if n!=10:quote(base,'buy',n,address,usdc,n*10**6)
            quote(base,'sell',n,address,usdc,quantity*n//10)
        print(base,'quotes complete',flush=True)
    with concurrent.futures.ThreadPoolExecutor(3) as pool:list(pool.map(work,bases))

def run_sells():
    from decimal import Decimal as D
    usdc=asset_config()['USDC']['starknet_address'];mapping={}
    aliases={'MRE7BTC':'mRe7BTC','MRE7YIELD':'mRe7YIELD','SUSN':'sUSN','WSTETH_CURRENT':'wstETH','DAI_CURRENT':'DAI'}
    for f in RAW.glob('quote-*-buy-10.json'):
        b=f.stem.split('-')[1]
        tokenfile=RAW/(f'tokenlookup-{aliases[b]}.json' if b in aliases else f'token-{b}.json')
        if not tokenfile.exists():continue
        t=json.loads(tokenfile.read_text()).get('data',{})
        if not t.get('address'):continue
        asset=b.split('_')[0];pair=asset+('/USDPLUS' if asset=='BROTHER' else '/USD')
        oracle=json.loads((RAW/('onchain-'+pair.replace('/','-')+'.json')).read_text())
        o=oracle['data'];price=D(str(o['price']))
        assert price>0
        mapping[b]={'token':t,'oracle_pair':pair,'sizing_price_usd':str(price),'oracle_received_at':oracle['received_at']}
    (ROOT/'quote-sizing.json').write_text(json.dumps(mapping,indent=2))
    def work(kv):
        b,m=kv
        for n in [10,100,1000,10000,100000]:
            f=RAW/f'quote-{b}-sell-{n}.json'
            if f.exists():f.with_suffix('.sizing-v1').write_text(f.read_text())
            amount=int(D(n)/D(m['sizing_price_usd'])*D(10)**m['token']['decimals'])
            quote(b,'sell',n,m['token']['address'],usdc,amount)
        print(b,'oracle-sized sell quotes collected',flush=True)
    with concurrent.futures.ThreadPoolExecutor(3) as pool:list(pool.map(work,mapping.items()))

if __name__=='__main__':
    import sys
    if sys.argv[-1]=='books':run_books()
    elif sys.argv[-1]=='dex':run_dex()
    elif sys.argv[-1]=='quotes':run_quotes()
    elif sys.argv[-1]=='sells':run_sells()
