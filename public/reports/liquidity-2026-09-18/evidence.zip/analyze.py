import datetime as dt
import json
import math
import statistics
from collect import ROOT, RAW, inventory, VENUES

def read(name):
    return json.loads((RAW/(name+'.json')).read_text())

def parse_book(source, data):
    if source=='BITGET':
        if data.get('code')!='00000':raise ValueError(data.get('msg','API error'))
        data=data['data']
    elif source=='BYBIT':
        if data.get('retCode')!=0:raise ValueError(data.get('retMsg','API error'))
        return data['result']['b'],data['result']['a']
    elif source=='HUOBI':
        if data.get('status')!='ok':raise ValueError(data.get('err-msg','API error'))
        data=data['tick']
    elif source in ('KUCOIN','LBANK'):
        data=data['data']
    elif source=='OKX':
        if data.get('code')!='0':raise ValueError(data.get('msg','API error'))
        data=data['data'][0]
    elif source=='KRAKEN':
        if data.get('error'):raise ValueError(str(data['error']))
        data=next(iter(data['result'].values()))
    return data['bids'],data['asks']

def depth(bids,asks,scale=1,quote_usd=1):
    bids=sorted([(float(x[0]),float(x[1])*scale) for x in bids if float(x[1])>0],reverse=True)
    asks=sorted([(float(x[0]),float(x[1])*scale) for x in asks if float(x[1])>0])
    if not bids or not asks:raise ValueError('Empty order book')
    mid=(bids[0][0]+asks[0][0])/2
    if not math.isfinite(mid) or bids[0][0]<=0 or asks[0][0]<bids[0][0]:raise ValueError('Invalid or crossed book')
    out={'mid':mid,'spread_bps':(asks[0][0]-bids[0][0])/mid*10000,'levels':[len(bids),len(asks)]}
    for pct in [1,2]:
        bid_sum=sum(p*q*quote_usd for p,q in bids if p>=mid*(1-pct/100))
        ask_sum=sum(p*q*quote_usd for p,q in asks if p<=mid*(1+pct/100))
        out[f'bid_{pct}pct_usd']=bid_sum
        out[f'ask_{pct}pct_usd']=ask_sum
        out[f'min_{pct}pct_usd']=min(bid_sum,ask_sum)
        # Incomplete unless returned prices reach the edge on both sides.
        out[f'complete_{pct}pct']=bids[-1][0]<=mid*(1-pct/100) and asks[-1][0]>=mid*(1+pct/100)
    return out

def analyze_books():
    rates=[]
    for s in ['BINANCE','BITSTAMP','BYBIT','BITGET','KRAKEN','COINBASE']:
        try:
            b,a=parse_book(s,read('book-'+s+'-USDT-USD')['data']);rates.append((float(b[0][0])+float(a[0][0]))/2)
        except (KeyError,ValueError,TypeError):pass
    usdt=statistics.median(rates)
    btc_data=read('book-BINANCE-BTC-USDT')['data']
    btc=(float(btc_data['bids'][0][0])+float(btc_data['asks'][0][0]))/2*usdt
    try:
        eb,ea=parse_book('KRAKEN',read('book-KRAKEN-EUR-USD')['data']);eur=(float(eb[0][0])+float(ea[0][0]))/2
    except (FileNotFoundError,KeyError,ValueError):eur=None
    instruments={x['instId']:x for x in read('okx-instruments')['data']['data']}
    out=[]
    for f in sorted(RAW.glob('book-*.json')):
        if f.stem.endswith('first-attempt'):continue
        _,source,base,quote=f.stem.split('-');raw=json.loads(f.read_text())
        row={'source':source,'base':base,'quote':quote,'instrument':f'{base}/{quote}'+(' perpetual' if source=='OKX' else ' spot'),
             'url':raw['url'],'at':raw['received_at'],'raw_file':f.name}
        try:
            if raw.get('status')!=200:raise ValueError('HTTP '+str(raw.get('status'))+' '+raw.get('error','')[:120])
            bids,asks=parse_book(source,raw['data']);scale=1
            if source=='OKX':
                i=instruments[f'{base}-{quote}-SWAP']
                if i['ctValCcy']!=base or i['ctType']!='linear':raise ValueError('Unsupported contract units')
                scale=float(i['ctVal'])*float(i.get('ctMult') or 1)
                row['contract_base_units']=scale
            fx={'USD':1,'USDT':usdt,'BTC':btc,'EUR':eur}[quote]
            if fx is None:raise ValueError('Unverified quote FX')
            row.update(depth(bids,asks,scale,fx))
            n=row['min_1pct_usd']
            row['assessment']='Deeper' if n>=100000 else ('Thin' if n>=10000 else 'Very thin')
            if n<100000 and not row['complete_1pct']:row['assessment']='Incomplete depth'
            if row['spread_bps']>=200:row['assessment']='Wide spread'
        except (KeyError,ValueError,TypeError,IndexError,StopIteration) as e:
            row.update(assessment='Unverified',error=str(e))
        out.append(row)
    (ROOT/'books-summary.json').write_text(json.dumps({'usdt_usd':usdt,'btc_usd':btc,'eur_usd':eur,'books':out},indent=2))
    for r in out:
        if r['source'] in VENUES:
            print(r['base'],r['source'],r['assessment'],round(r.get('min_1pct_usd',0)),round(r.get('spread_bps',0),2),r.get('complete_1pct'),r.get('error','')[:90])

if __name__=='__main__':analyze_books()
