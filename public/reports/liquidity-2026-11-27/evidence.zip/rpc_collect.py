"""Read-only current and historical oracle evidence from a public RPC."""
import concurrent.futures
import datetime as dt
import hashlib
import json
import os
import pathlib
import urllib.parse
import urllib.request
from collect import ROOT, RAW, inventory

RPC=os.environ.get('STARKNET_RPC_URL','https://starknet.api.onfinality.io/public')
RPC_SOURCE=urllib.parse.urlsplit(RPC).hostname
CONTRACT='0x2a85bd616f912537c50a49a4076db02c00b29b2cdc8a197ce92ed1837fa875b'
SELECTORS={'get_data_median':'0x24b869ce68dd257b370701ca16e4aaf9c6483ff6805d04ba7661f3a0b6ce59',
           'get_data_entries':'0x191271e046e370673c92201fd11e66bffd995383719b72ac7ef4db0d67ce639'}
(RAW/'rpc').mkdir(exist_ok=True)
def rpc(method,params):
    payload={'jsonrpc':'2.0','id':1,'method':method,'params':params}
    key=hashlib.sha256(json.dumps(payload,sort_keys=True).encode()).hexdigest()
    out=RAW/'rpc'/(key+'.json')
    if out.exists():record=json.loads(out.read_text())
    else:
        req=urllib.request.Request(RPC,data=json.dumps(payload).encode(),headers={'Content-Type':'application/json'})
        with urllib.request.urlopen(req,timeout=30) as r:data=json.load(r)
        record={'rpc_host':RPC_SOURCE,'request':payload,'received_at':dt.datetime.now(dt.timezone.utc).isoformat(),'response':data}
        out.write_text(json.dumps(record))
    if 'error' in record['response']:raise ValueError(record['response']['error'])
    return record['response']['result']
def call(name,pair,block):
    return rpc('starknet_call',{'request':{'contract_address':CONTRACT,'entry_point_selector':SELECTORS[name],
        'calldata':['0x0',hex(int.from_bytes(pair.encode(),'big'))]},'block_id':{'block_number':block}})
def decode(x):return int(x,16).to_bytes((int(x,16).bit_length()+7)//8,'big').decode()
def snapshot(block,label,pairs):
    meta=rpc('starknet_getBlockWithTxHashes',{'block_id':{'block_number':block}})
    def read(pair):
        row={'pair':pair,'block':block}
        for name in SELECTORS:
            try:
                vals=call(name,pair,block)
                if name=='get_data_median':
                    nums=[int(x,16) for x in vals]
                    row.update(raw=vals,price=nums[0]/10**nums[1],decimals=nums[1],timestamp=nums[2],sources=nums[3])
                else:
                    assert len(vals)==1+int(vals[0],16)*7, (pair,len(vals))
                    entries=[]
                    for i in range(1,len(vals),7):
                        assert int(vals[i],16)==0
                        entries.append({'pair_id':pair,'source':decode(vals[i+2]),'publisher':decode(vals[i+3]),
                            'last_updated_timestamp':int(vals[i+1],16),'price':vals[i+4]})
                    row['entries']=entries
            except Exception as e:row[name+'_error']=str(e)
        print(label,pair,'sources',row.get('sources'),'errors',[k for k in row if k.endswith('_error')],flush=True)
        return row
    with concurrent.futures.ThreadPoolExecutor(3) as pool:results=list(pool.map(read,pairs))
    result={'at':dt.datetime.now(dt.timezone.utc).isoformat(),'rpc_host':RPC_SOURCE,'contract':CONTRACT,
            'block':block,'block_hash':meta['block_hash'],'block_timestamp':meta['timestamp'],'results':results}
    (ROOT/(label+'-oracle.json')).write_text(json.dumps(result,indent=2))
    return result
if __name__=='__main__':
    import sys
    pairs=sorted({p for p,s in inventory()}|{'BTC/EUR','WBTC/BTC'})
    latest=rpc('starknet_blockNumber',[])
    if sys.argv[-1]=='october':
        target=int(dt.datetime(2026,11,1,tzinfo=dt.timezone.utc).timestamp())
        lo,hi=15058798,latest
        while lo+1<hi:
            mid=(lo+hi)//2
            b=rpc('starknet_getBlockWithTxHashes',{'block_id':{'block_number':mid}})
            if b['timestamp']<target:lo=mid
            else:hi=mid
        print('October final block',lo,flush=True)
        snapshot(lo,'october',pairs)
        rpc('starknet_getBlockWithTxHashes',{'block_id':{'block_number':hi}})
    else:snapshot(latest,'november',pairs)
