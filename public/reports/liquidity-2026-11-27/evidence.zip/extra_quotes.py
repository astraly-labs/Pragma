"""Refresh metadata and indicative quotes for named tokens missing from SDK lookup."""
import concurrent.futures
import json
from collect import ROOT, RAW, get, quote, asset_config

aliases={'LBTC':'LBTC','UNIBTC':'uniBTC','USN':'USN','SUSN':'sUSN','MRE7BTC':'mRe7BTC',
         'MRE7YIELD':'mRe7YIELD','DAI_CURRENT':'DAI','WSTETH_CURRENT':'wstETH'}
usdc=asset_config()['USDC']['starknet_address']
def work(kv):
    base,alias=kv
    r=get('tokenlookup-'+alias,'https://starknet.api.avnu.fi/v1/starknet/tokens/'+alias)
    token=r.get('data',{})
    if not token.get('address') or token.get('symbol','').lower()!=alias.lower():
        print(base,'token unavailable',flush=True);return
    q=quote(base,'buy',10,token['address'],usdc,10*10**6)
    if not isinstance(q.get('data'),list) or not q['data']:
        print(base,'baseline unavailable',flush=True);return
    quantity=int(q['data'][0]['buyAmount'],16)
    for n in [10,100,1000,10000,100000]:
        if n!=10:quote(base,'buy',n,token['address'],usdc,n*10**6)
        quote(base,'sell',n,token['address'],usdc,quantity*n//10)
    print(base,'quotes complete',flush=True)
with concurrent.futures.ThreadPoolExecutor(2) as p:list(p.map(work,aliases.items()))
